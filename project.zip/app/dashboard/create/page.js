import React from "react";
import VerificationForm from "./_component/VerificationForm";

const CreatePage = () => {
  return <VerificationForm />;
};

export default CreatePage;
